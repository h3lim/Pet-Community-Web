package com.community.users;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.sql.DataSource;
import com.community.servlet.MyOracleConnection;
import com.community.util.DBUtil;
import com.community.model.User;

public class UserDAO {
	
	private static final String INSERT_USER_SQL = "INSERT INTO users (username, password, email, nickname, dog_name, address, phone_number, birthday) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    public boolean registerUser(User user) {
        try (Connection connection = DBUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USER_SQL)) {
            preparedStatement.setString(1, user.getUsername());
            preparedStatement.setString(2, user.getPassword());
            preparedStatement.setString(3, user.getEmail());
            preparedStatement.setString(4, user.getNickname());
            preparedStatement.setString(5, user.getDogName());
            preparedStatement.setString(6, user.getAddress());
            preparedStatement.setString(7, user.getPhoneNumber());
            preparedStatement.setDate(8, new Date(user.getBirthday().getTime()));
            return preparedStatement.executeUpdate() > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean isUsernameExist(String username) {
        String query = "SELECT COUNT(*) FROM users WHERE username = ?";
        try (Connection connection = DBUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, username);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean isNicknameExist(String nickname) {
        String query = "SELECT COUNT(*) FROM users WHERE nickname = ?";
        try (Connection connection = DBUtil.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(query)) {
            preparedStatement.setString(1, nickname);
            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                return resultSet.getInt(1) > 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
	
	public UserVO userLogin(String username, String password) {
		// 자바 connect
		MyOracleConnection moc = new MyOracleConnection(); 
		Connection conn = null;
		PreparedStatement ps = null;
		ResultSet rs = null;
		//DataSource ds = null;
		UserVO uvo = null;
		boolean userCheck = false;
		
		try {
			conn = moc.oracleConn();
			String sql = "select username, password from users where username=? and password=?";
			ps = conn.prepareStatement(sql);
			ps.setString(1, username);
			ps.setString(2, password);
			rs = ps.executeQuery();
			
			if(rs.next()) {
				uvo = new UserVO();
				uvo.setUsername(rs.getString("username"));
				uvo.setPassword(rs.getString("password"));
				userCheck = true;
			}
		} catch (SQLException e) {
			
			e.printStackTrace();
		} finally {
			moc.oracleClose(conn, ps, rs);
		}
		return uvo;
	}
	public static void main(String[] args) {
		UserDAO dao = new UserDAO();
        // 유효한 username과 password를 입력해야 함
        UserVO uvo = dao.userLogin("a123", "a123123");

        if (uvo != null) {
            System.out.println("Username: " + uvo.getUsername());
        } else {
            System.out.println("Login failed");
        }
}
		
	}