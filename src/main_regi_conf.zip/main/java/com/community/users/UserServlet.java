package com.community.users;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/UserServlet")
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public UserServlet() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//doPost(request, response);
		//로그아웃
//		HttpSession session = request.getSession();
//		//세션 종료
//		session.invalidate();
//		//세션 유효타임
//		session.setMaxInactiveInterval(200);
//		response.sendRedirect("index.jsp");
  }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");
		
		String pagecode = request.getParameter("pagecode");
		UserDAO dao = new UserDAO();
		
		if(pagecode.equals("P002")) {
			String userid = request.getParameter("username");
			String password = request.getParameter("password");
			UserVO loginCheck = dao.userLogin(userid, password);
			if(loginCheck != null) {
				HttpSession session = request.getSession();
				session.setAttribute("username", loginCheck.getUsername());
				//메인페이지로 리디렉션
				response.sendRedirect("index.jsp");
				
			} else {
//				PrintWriter out = response.getWriter();
//				out.write("<script>alert('비번오류');location.href='news.jsp';</script>");
//				out.flush();
//				out.close();
				HttpSession session = request.getSession();	
				session.setAttribute("errorMessage", "아이디 또는 비밀번호가 잘못되었습니다.");
                response.sendRedirect("login.jsp");
			}
		} else if (pagecode.equals("logout")) {
            HttpSession session = request.getSession();
            session.invalidate();
            response.sendRedirect("login.jsp");
		}else {
			response.sendRedirect("info.jsp");
			return;
		}
		doGet(request,response);
	}

}
